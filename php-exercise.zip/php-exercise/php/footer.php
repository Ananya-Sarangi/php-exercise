
<footer><p class="s">
<?php
date_default_timezone_set('Asia/Kolkata');
echo "" . date("Y") ;
?>   
</p></footer>
