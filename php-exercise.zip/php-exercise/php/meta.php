
    <title>meta</title>
    <meta charset="utf-8">
        <meta name="author" content="learn.expandedmetrics.com">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
            
        <title>D12.E1 · Multipage PHP website</title>

        <!-- Socials -->
        <meta property="og:title" content=" " />
        <meta property="og:type" content="website" />
        <meta property="og:description" content=" " />
        <meta property="og:image" content="assets/ .jpg" />
        <meta property="og:url" content=" .com" />
        <meta name="twitter:title" content=" ">
        <meta name="twitter:description" content=" ">
        <meta name="twitter:image" content="assets/ .jpg">
        <meta name="twitter:card" content="assets/ .jpg">

        <!-- CSS -->
        <link href="../assets/style.css" rel="stylesheet" type="text/css">
                
        <!--JavaScript -->
        <script type="text/javascript" src="../assets/script.js" defer></script> 

        <!-- Favicons -->
        <link rel="shortcut icon" href="../assets/favicon.ico"> 

